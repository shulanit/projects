var dataPoints = [[],[],[],[],[]];//the points build the graphs
var xAxis = 0;
var chart = null;
var symbolsToGraphs = [];
var symbolsToAjax = "";
var count = 0;
var timing = null;

//the function clear page, and build the graphs 
function graph(checkedCoins) {
	$(".coins").html("");
	$(".coins").removeClass('about');
	$("#chartContainer").show();
	$(".gif").css("display","block");

	if(symbolsToGraphs){
		symbolsToGraphs = [];
		symbolsToAjax = "";
		dataPoints = [[],[],[],[],[]];
		count = 0;
		xAxis = 0;
	}

	//convert the symbols to Upper Case
	if (checkedCoins.length > 0) {
		for (let i = 0; i < checkedCoins.length; i++) {
			symbolsToGraphs.push(checkedCoins[i].symbol.toUpperCase());
			symbolsToAjax += checkedCoins[i].symbol.toUpperCase();
			if(i != checkedCoins.length-1){
				symbolsToAjax += ",";
			}
		}
	}

	//give values on checked coins from API
	$.ajax({
		url: `https://min-api.cryptocompare.com/data/pricemulti?fsyms=${symbolsToAjax}&tsyms=USD`,
		type: "get",
		data: {},
		success: function (result) {
			console.log(result);
			timing = setInterval(function(){
				data(result);
				if (count > 100) {
					clearInterval(timing);
				}
				else{
					count++;
				}
				chart.render();
				$(".gif").css("display","none");
			}, 2000);
		},
		error: function (xhr) {
			console.log("Error:", xhr);
		}
	});

	chart = new CanvasJS.Chart("chartContainer", {
		title:{
			text:"The currency value is live"
		},
		axisY: [{
			title: "Values",
			lineColor: "blue",
			tickColor: "blue",
			labelFontColor: "blue",
			titleFontColor: "blue",
			prefix: "$"
		}],
		toolTip: {
			shared: true
		},
		legend: {
			cursor: "pointer",
			verticalAlign: "top",
			fontSize: 14
		},
		data: [{
			type: "line",
			name: `${symbolsToGraphs[0]}`,
			color: "#369EAD",
			showInLegend: true,
			dataPoints: dataPoints[0]
		},
		{
			type: "line",
			name: `${symbolsToGraphs[1]}`,
			color: "#C24642",
			showInLegend: true,
			dataPoints: dataPoints[1]
		},
		{
			type: "line",
			name: `${symbolsToGraphs[2]}`,
			color: "#b906f9",
			showInLegend: true,
			dataPoints: dataPoints[2]
		},
		{
			type: "line",
			name: `${symbolsToGraphs[3]}`,
			color: "#0b7a18",
			showInLegend: true,
			dataPoints: dataPoints[3]
		},
		{
			type: "line",
			name: `${symbolsToGraphs[4]}`,
			color: "#7a0b0b",
			showInLegend: true,
			dataPoints: dataPoints[4]
		}
		]
	});
	chart.render();
}

//the function fills the array 'dataPoints' with objects. each object is a point on the graph.
function data(result){
	for (var i = 0; i < symbolsToGraphs.length; i++) {
		if( result[ symbolsToGraphs[i] ] ){
			dataPoints[i].push({
				x: xAxis,
				y: result[symbolsToGraphs[i]].USD
			});
		}
	}
	xAxis += 2;
}

