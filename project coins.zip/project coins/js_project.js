$(document).ready(function () {
    GiveCoins();
});

//the function give with Ajax the coins,and send to print function 
function GiveCoins() {
$(".gif").css("display","block");
clearInterval(timing);   
   $.ajax({
        url: "https://api.coingecko.com/api/v3/coins/list",
        type: "get",
        data: {},
        success: function (result) {
            $("#chartContainer").hide();
            PrintCoins(result);
            $(".gif").css("display","none");
            
        },
        error: function (xhr) {
            console.log("Error:", xhr);
        }
    });
}

//the function print the coins to cubes with button more info.
//more info on the coin According to the value of the dollar = USA, euro,and shekel = ILS.
function PrintCoins(result) {
    $(".coins").removeClass('about');
    $(".coins").html("");
    $(".coins").addClass('row');
    for (let i = 0; i < result.length && i<200;  i++) {
        
        let cube = $(`<div class='col-md-4 card' id='${result[i].id}' style='background-color:lightgreen;'>
            <div class="card-body">
            <label class="switch">
                <input type="checkbox" id='${result[i].id}' symbol='${result[i].symbol}' class="switch" onclick="checkIfSelected(this,'${result[i].symbol}','${result[i].id}')">
                <span class="slider round" id=${result[i].id}></span>
            </label>
            <div class="symbol">${result[i].symbol}</div>
            <div class="id">${result[i].id}</div>
            <div class='btn btn-primary info' data-toggle='collapse' href='#collapse-${result[i].id}'>more info</div>
            <div class='more_info' id='collapse-${result[i].id}'></div>
        
            </div>
        </div>`);
        
        $(cube).find(".info").on("click", function () {//Equivalent to cube.querySelector(".info")
            GetMoreInfo(result[i].id);
        });
        $(".coins").append(cube);
    }
    rememberCoins();
}

//because the page is reloaded each time,
//the function marks the selected coins at the begining 
function rememberCoins(){
    for(let i=0; i<checkedCoins.length; i++){
        var thisId = checkedCoins[i].id;
        $("input[id='"+thisId+"']").attr("checked",true);
    }
}

var checkedCoins = [];
//all click on the checkbox the function checker if the coin existing
//in array 'checkedCoins' or not, and add or out from array. if have more
//five coins calling Popup
function checkIfSelected(box,coin_symbol,coin_id){//box = input finel
    if(checkedCoins.findIndex(function(coin) {
        return coin.id === coin_id;}) === -1){//-1 undefind
        if( checkedCoins.length < 5){
        checkedCoins.push({id:coin_id,symbol:coin_symbol});
        }
        else{
            PopUp(box,checkedCoins);
        }
    }
    else{
        checkedCoins.splice(checkedCoins.findIndex((e) =>{
            return e.id === coin_id;
        }),1);
        console.log(checkedCoins);
    }
}
//constructive new array with the checked coins in popup,including six coin(box)
function Change(box) {
    checkedCoins = [];
    $("#popup_list input:checkbox").each(function(){
        if($(this).is(":checked") == true){
            checkedCoins.push({
                id:$(this).attr('id'),
                symbol:$(this).attr('symbol')
            })
        }
        else{
            let id = ".coins input[symbol = '" +$(this).attr('symbol') + "']";
            $(id).prop('checked',false);
        }
    });
    checkedCoins.push({
        id:$(box).attr('id'),
        symbol:$(box).attr('symbol')
    })
    console.log(checkedCoins);
    $('#myModal').modal('hide');    
}

let saveChangesWasPressed = false;

//constructive the popup window with checked coins
function PopUp(box,arr){
    saveChangesWasPressed = false;
    $('#myModal').modal();
    $('#change').prop("disabled",true);
    var list_coins = $('<div class = "selected"><ul id="popup_list"></ul></div>')
    for(let i = 0; i<arr.length; i++){ 
        var li = $(`<li>${arr[i].symbol}</li>`);
        $(li).append(`<input type='checkbox' symbol='${arr[i].symbol}' id='${arr[i].id}' checked></input>`);
        $(":checkbox", li).change(function() {
            $("#change").prop("disabled", $(":checkbox:not(:checked)", list_coins).length == 0);///check how many not checked
        });
        $("ul", list_coins).append(li);   
    }
    
    $(".selected_coins").html("");
    $(".selected_coins").append(list_coins);

    
    $("#change").click(function(){
        saveChangesWasPressed = true;
        Change(box);
    });
    
    //close popup, and cancel the change checked coins array
    $("#myModal").on("hide.bs.modal", function(){
        Cancel(box);
    });

    $("#myModal").on("hidden.bs.modal", function() {
        $("#myModal").off("hidden.bs.modal");//cancel double code
        $("#myModal").off("hide.bs.modal");//cancel double code
        $("#change").off("click");//cancel double code (CLICK)
    });

}

//cancel and exit from popup 
function Cancel(box){
    if (!saveChangesWasPressed) {
        $(box).prop("checked", false);
    }
}

//give in Ajax more info on the coin. if tha last call was more 
//than two minutes ago,give new data. if not, give data from local storage
//according to last call. 
function GetMoreInfo(id) {
    let coins = localStorage.coins ? JSON.parse(localStorage.coins) : {};
    if (coins[id] && Date.now() < coins[id].time + 120000) {//if the object and date now, not big from 2 minutes
        PrintMoreInfo(coins[id].info);
    }
    else {
        $(".gif").css("display","block");
        $.ajax({
            url: "https://api.coingecko.com/api/v3/coins/" + id,
            type: "get",
            data: {},
            success: function (data) {
                coins[id] = {//id is key to coins object
                    time: Date.now(),
                    info: data,
                };
                localStorage.coins = JSON.stringify(coins);
                PrintMoreInfo(data);
                $(".gif").css("display","none");
            },
            error: function (xhr) {
                console.log("Error:", xhr);
            }
        });
    }
}

//print more info on the coin according to USD,EUR,ILS. 
//printed in cube under the button 'more info'.
function PrintMoreInfo(data) {
    
    var content = $("<p></p>");
    $(content).addClass("content");
    $(content).append("<image src='" + data.image.small + "'>");
    $(content).append("<div>" + (data.market_data.current_price.usd).toFixed(3) + ' <i class="fas fa-dollar-sign"></i></div>');
    $(content).append("<div>" + (data.market_data.current_price.eur).toFixed(3) + ' <i class="fas fa-euro-sign"></i></div>');
    $(content).append("<div>" + (data.market_data.current_price.ils).toFixed(3) + ' <i class="fas fa-shekel-sign"></i></div>');

    $("#" + data.id + " .more_info").html("").append(content);

}

//search coin according to id, and only prints it.
//if is undefined jumping window with error.  
function searchCoin() {
    var search = $("#search").val();

    if (search.length > 0) {
        $(".gif").css("display","block");
        my_url = "https://api.coingecko.com/api/v3/coins/" + search;
        $.ajax({
            url: my_url,
            type: "get",
            data: {},
            success: function (result) {
                //console.log(result);
                $(".coins").html("");

                PrintCoins([result]);
                $(".gif").css("display","none");
            },
            error: function (xhr) {
                console.log("Error:", xhr);
                $(".gif").css("display","none");
                alert("the coin is undefined");
               
            }
        });
    }
    else {
        $(".gif").css("display","block");
        my_url = "https://api.coingecko.com/api/v3/coins/list";
        $.ajax({
            url: my_url,
            type: "get",
            data: {}, 
            success: function (result) {
                //console.log(result);
                $(".coins").html("");
                PrintCoins(result);
                $(".gif").css("display","none");

            },
            error: function (xhr) {
                console.log("Error:", xhr);
            }
        });
    }

}

//constructive the page about
function about() {
    $(".coins").html("");
    $(".coins").addClass('about');
    $(".coins").removeClass('row');
    $("#chartContainer").hide();
    clearInterval(timing);
    var about = "";
    about += '<div class="about_cube">';
    about += `<h3> Name: Shulamit Luzon </h3>`;
    about += `<p> Phone: 0545212366 </p>`;
    about += `<p> Mail: shulamit013 @gmail.com </p>`;
    about += '<p> Description Project: The project is on virtual currencies. it displays the values of different virtual currencies according to the dollar, euro and shekel exchange rate, update all two minutes, and displays the results using graphs  </p>';
    about += '<img src = "images/profile.jpg" id="profile" />';
    about += '</div>';
    $(".coins").append(about);

}
