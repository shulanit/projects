// Forms
users = [];

window.onload = function(){

    var users = loadUsersFromStorage();
    for( var i = 0; i < users.length ; i++){
        addRowToTable( users[i] );
    }
    

    // on page load
    document.querySelector("#save_user").addEventListener("click",function(){
        newUser();
    });

    var temp = [1,2,5,,20,,,60];
    for( var i = 0; i < temp.length ; i++ ){
        //console.log(i + ":" ,temp[i]);
    }

    // Foreach Loop
    // for( var index in array ){ code... }
    for( var key in temp ){
        //console.log(key + ":" ,temp[key]);
    }

}

function newUser(){
    console.log("New User");
    var name = document.querySelector("#name").value;
    var age = document.querySelector("#age").value;
    var mail = document.querySelector("#email").value;
    var phone = document.querySelector("#phone").value;
    var gender = document.querySelector("#gender").value;

    if( age < 999 && mail.indexOf("@") > -1 && (mail.indexOf(".com") > -1 || mail.indexOf(".co.il") > -1 ) && phone.length == 10 ){
        // All Good
        document.querySelector("#error_alert").style = "display:none;";
        var new_user = {};
        new_user.name = name;
        new_user.age = age;
        new_user.mail = mail;
        new_user.phone = phone;
        new_user.gender = gender;
        /*
        var new_user = [];
        new_user["name"] = name;
        new_user["age"] = age;
        new_user["mail"] = mail;
        new_user["phone"] = phone;
        new_user["gender"] = gender;
        */
       //console.log( new_user );
        users = loadUsersFromStorage();
        for( var i = 0 ; i < users.length ; i++ ){
            if( users[i].phone == new_user.phone ){
                alert( "user Exist Select new Phone!");
                return;
            }
        }
        users.push( new_user );
        //console.log( users );
        //console.log( JSON.stringify(users) );
        addRowToTable( new_user );

        saveUsersToStorage( users );

        //addUserNoLoop( new_user );
        //console.log( users );
    }else{
        // error
        document.querySelector("#error_alert").style = "display:block;";
    }

    
}


function addRowToTable( user ){
    var tr = document.createElement("tr");
    
    for( var key in user ){
        //console.log(key + ":" ,user[key]);
        var td = document.createElement("td");
        td.innerText = user[key];
        tr.appendChild(td);
    }

    var td_delete = document.createElement("td");
    td_delete.innerHTML = "<i class='fa fa-trash'></i>";
    td_delete.addEventListener("click",function(){
        users = loadUsersFromStorage();
        document.querySelector("#users_table").removeChild(tr);
        for( var i = 0; i < users.length ; i++ ){
            if( users[i].phone == user.phone ){
                users.splice( i,1 );
                break;
            }
        }
        saveUsersToStorage( users );
        console.log( users );
    });
    tr.appendChild(td_delete);

    document.querySelector("#users_table").appendChild(tr);
}

function addUserNoLoop( user ){
    var tr = document.createElement("tr");

    var td_name = document.createElement("td");
    td_name.innerText = user["name"];
    tr.appendChild(td_name);

    var td_age = document.createElement("td");
    td_age.innerText = user["age"];
    tr.appendChild(td_age);

    var td_mail = document.createElement("td");
    td_mail.innerText = user["mail"];
    tr.appendChild(td_mail);

    var td_phone = document.createElement("td");
    td_phone.innerText = user["phone"];
    tr.appendChild(td_phone);

    var td_gender = document.createElement("td");
    td_gender.innerText = user["gender"];
    tr.appendChild(td_gender);
    
    var td_delete = document.createElement("td");
    td_delete.innerHTML = "<i class='fa fa-trash'></i>";
    td_delete.addEventListener("click",function(){
        console.log("Delete ",tr);
        users = loadUsersFromStorage();
        document.querySelector("#users_table").removeChild(tr);
        for( var i = 0; i < users.length ; i++ ){
            if( users[i]["phone"] == user["phone"] ){
                users.splice( i,1 );
            }
        }
        saveUsersToStorage( users );
        console.log( users );
    });
    tr.appendChild(td_delete);

    document.querySelector("#users_table").appendChild(tr);
}


function saveUsersToStorage( users ){
    localStorage.users = JSON.stringify(users);
}

function loadUsersFromStorage(){
    if( localStorage.users ){
        return JSON.parse( localStorage.users );
    }

    return [];
}


