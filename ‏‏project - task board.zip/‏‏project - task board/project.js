window.onload = function(){
    document.querySelector("#save").addEventListener("click",function(){
        save();
    });
    notes = loadDataFromLocalStorage();
    //console.log(notes);
    if(notes){
        for (var i = 0; i < notes.length; i++) {
            createNotesInOnload(notes[i]);
        }
    } 
}

var notes = [];

function save(){
    
    var task = document.querySelector("textarea").value;
    var myTime = document.querySelector("#time").value;
    var myDate = document.querySelector(".date").value;

    var mistake = document.querySelector(".error_write");
    var time = document.querySelector(".error_date");
    var incorrect_time = document.querySelector(".incorrect_time");
    var incorrect_date = document.querySelector(".incorrect_date");
    
    if(task == ""){
        mistake.style.visibility = "visible";
    } else {
        mistake.style.visibility = "hidden";
    }

    if(myDate == ""){
        time.style.visibility = "visible";
        incorrect_date.style.visibility = "hidden";
    } else {
        time.style.visibility = "hidden";
    }

    if(myTime == ""){
        incorrect_time.style.visibility = "hidden";
    }
    
    if((task != "") && (myDate != "")){
    mistake.style.visibility = "hidden";
    time.style.visibility = "hidden";

    var check = validation(myTime,myDate,incorrect_time,incorrect_date);
    if(check == false){
        return;
    }
    

    var note = {
        text: task,
        date: myDate,
        time: myTime 
    };
    
    var new_note = {};
    new_note.text = task;
    new_note.date = myDate;
    new_note.time = myTime;
    notes.push(new_note);

    saveInStorage(notes);
    appendNote(note);
    
    }
    document.querySelector("textarea").value = '';
    document.querySelector(".date").value = '';
    document.querySelector("#time").value = '';
    
}

function appendNote(note){
    
    var task = document.createElement("div");
    task.classList.add("task");
    var cancel = document.createElement("div");
    task.appendChild(cancel);
    cancel.classList.add("cancel");
    var content = document.createElement("div");
    content.classList.add("content");
    task.appendChild(content);
    var new_date = document.createElement("div");
    new_date.classList.add("new_date");
    task.appendChild(new_date);
    var new_time = document.createElement("div");
    new_time.classList.add("new_time");
    task.appendChild(new_time);

    cancel.innerHTML = '<i class="fa fa-times"></i>';
    cancel.addEventListener("click", function(){
        notes = loadDataFromLocalStorage();
        document.querySelector(".tasks").removeChild(task);
        for ( var i = 0; i<notes.length; i++ ){
            if( (notes[i]["text"] == note["text"]) && (notes[i]["date"] == note["date"]) && (notes[i]["time"] == note["time"]) ){
                notes.splice( i,1 );
            }
        }
        saveInStorage(notes);
        //console.log(notes);
    });

    
    content.innerText = note.text;
    new_date.innerText = note.date;
    new_time.innerText = note.time;
    
    document.querySelector(".tasks").appendChild(task);
}

function createNotesInOnload(note){
    appendNote(note);   
}

function saveInStorage(arr_notes){
    localStorage.notes = JSON.stringify(notes);
}

function loadDataFromLocalStorage(){
    if(localStorage.notes){
        return JSON.parse(localStorage.notes);
    }
    else{
        return [];
    }
}

function validation(myTime,myDate,incorrect_time,incorrect_date){
    var time_expression = /^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/g;
    var date_expression = /^(?:(?:31(\/|-|\.)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(\/|-|\.)(?:0?[1,3-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(\/|-|\.)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})$/g;
    
    var check_time = myTime;
    var check_date = myDate;
    
    let ok = true;
    if( time_expression.test( check_time ) ){ // test -> return true if the string match the expression else return false
        incorrect_time.style.visibility = "hidden";
        ok =  true;
    }else{
        incorrect_time.style.visibility = "visible";
        ok =  false;
    }

    if( date_expression.test( check_date ) ){ // test -> return true if the string match the expression else return false
        incorrect_date.style.visibility = "hidden";
        ok = true;
    }else{
        incorrect_date.style.visibility = "visible";
        ok = false;
    }
    return ok;
}